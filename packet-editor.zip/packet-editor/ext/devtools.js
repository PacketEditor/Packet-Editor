chrome.devtools.panels.create("Packet Editor", "editor-16.png", "tools.html", function(panel){});
